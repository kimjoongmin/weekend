let a = ["a","b","c"];
let b = [...a];
b.push("d");
let aa = 10;
let bb = aa;
aa = 20;
console.log(a+"=="+b);
const searchResult = $("#searchResult");
function searchImage(_img){
    $.ajax({
        url:`https://dapi.kakao.com/v2/search/image?query=${_img}&size=48`,
        //url:`https://dapi.kakao.com/v2/search/vclip?query=${_img}&size=20`,
        headers:{
            Authorization:"KakaoAK 93a2a9bdab634d61eb0325d93a6e624e"
        },
        success:function(res){
            const imgList = [...res.documents];
            let output = "";
            searchResult.html("<ul></ul>");
            const resultUL = searchResult.find("ul");
            $.each(imgList,function(i,item){
                output+=`
                    <li><a href="${item.image_url}" data-fancybox="gallery"><img src="${item.thumbnail_url}"></a></li>
                `
            });
            console.log(output);
            resultUL.html(output);
            gsap.from("#searchResult li",{
                scale:0,
                ease:"power4",
                stagger:0.02
            })
        }
    })
}
function searchVclip(_img){
    $.ajax({
        
        url:`https://dapi.kakao.com/v2/search/vclip?query=${_img}&size=20`,
        headers:{
            Authorization:"KakaoAK 93a2a9bdab634d61eb0325d93a6e624e"
        },
        success:function(res){
            const imgList = [...res.documents];
            let output = "";
            searchResult.html("<ul></ul>");
            const resultUL = searchResult.find("ul");
            $.each(imgList,function(i,item){
                output+=`
                    <li><a href="${item.url}" data-fancybox="gallery"><img src="${item.thumbnail}"></a></li>
                `
            });
            console.log(output);
            resultUL.html(output);
            gsap.from("#searchResult li",{
                scale:0,
                ease:"power4",
                stagger:0.02
            })
        }
    })
}
$("#btnSearch").on("click",function(){
    const search= $("#searchTxt").val();
    searchVclip(search);
    $("#recentSearchWord .list").append(`<li>${search}</li>`);
});
$("#searchTxt").on("keyup",function(e){
    //console.log("aaa");
    //console.log(e);
    if(e.keyCode===13){
        const search= $("#searchTxt").val();
        searchVclip(search);
        $("#recentSearchWord .list").append(`<li data-word="${search}">${search}</li>`);
    }
});
$("#recentSearchWord .list").on("click","li",function(){
    const search= $(this).data("word");
    searchVclip(search);
})