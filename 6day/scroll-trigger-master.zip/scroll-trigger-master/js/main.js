gsap.to(".red",{
    x:1500,
    rotation:180,
    //scrollTrigger:".red"
    scrollTrigger:{
        trigger:".red",
        markers:true,
        start:"top center", //첫번째 매개변수 트리거의 최상단을 어디다 둘거냐 두번째가 화면 최상단.
        end:"bottom top"  , //첫번째 매개변수 트리거의 하단을 어디다 둘거냐 두번째가 화면 하단.
        scrub:true,
        pin:true
    }
});
gsap.to(".green",{
    x:1500,
    rotation:180,
    scrollTrigger:{
        trigger:".green",
        markers:{
            
        },
        start:"top center+=200",
        end:"bottom top+=200"
    }

});
gsap.to(".blue",{
    x:1500,
    rotation:180,
    scrollTrigger:".blue"
});
